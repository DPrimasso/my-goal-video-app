const {getRenderProgress} = require('@remotion/lambda/client');
const {getOrCreateBucket} = require('@remotion/lambda');

exports.handler = async (event) => {
  try {
    const qs = (event && event.queryStringParameters) || {};
    const renderId = qs.renderId || qs.render_id || qs.id;

    const REGION = process.env.AWS_REGION || 'eu-west-1';
    const FUNCTION_NAME = process.env.REMOTION_LAMBDA_FUNCTION_NAME;

    if (!renderId) {
      return { statusCode: 400, body: JSON.stringify({ error: 'Missing renderId' }) };
    }
    if (!FUNCTION_NAME) {
      return { statusCode: 500, body: JSON.stringify({ error: 'Missing REMOTION_LAMBDA_FUNCTION_NAME' }) };
    }

    const envBucket = process.env.ASSET_BUCKET || process.env.BUCKET_NAME;
    let bucketName = qs.bucketName || qs.bucket || envBucket;
    if (!bucketName) {
      const r = await getOrCreateBucket({ region: REGION });
      bucketName = r.bucketName;
    }

    const status = await getRenderProgress({
      region: REGION,
      functionName: FUNCTION_NAME,
      renderId,
      bucketName,
    });

    return { statusCode: 200, body: JSON.stringify(status) };
  } catch (e) {
    console.error(e);
    return { statusCode: 500, body: JSON.stringify({ error: String(e && e.message ? e.message : e) }) };
  }
};
